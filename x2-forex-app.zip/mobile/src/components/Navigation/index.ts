export { BottomTabs } from './BottomTabs';
